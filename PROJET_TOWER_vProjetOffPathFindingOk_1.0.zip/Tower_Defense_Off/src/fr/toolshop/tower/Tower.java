package fr.toolshop.tower;

public abstract class Tower
{
	protected int id;
	protected float buildCost;
	protected int range;
	protected float speedAttaque;
	protected int level;
	// *****************************************
	// ************** CONSTRUCTORS ************
	// *****************************************
	public Tower(int id, float buildCost, int range, float speedAttaque, int level)
	{
		super();
		this.id = id;
		this.buildCost = buildCost;
		this.range = range;
		this.speedAttaque = speedAttaque;
		this.level = level;
	}
	// ***********************************************
	// ********** ABSTRACTS PROCEDURES **************
	// ***********************************************
	public abstract void action();
	public abstract boolean testPortee();
	public abstract void upgrade();
}
